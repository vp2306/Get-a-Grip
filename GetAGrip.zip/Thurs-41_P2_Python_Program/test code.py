ip_address = 'localhost' # Enter your IP Address here
project_identifier = 'P2B' # Enter the project identifier i.e. P2A or P2B
#--------------------------------------------------------------------------------
import sys
import random
sys.path.append('../')
from Common.simulation_project_library import *



hardware = False
QLabs = configure_environment(project_identifier, ip_address, hardware).QLabs
arm = qarm(project_identifier,ip_address,QLabs,hardware)
potentiometer = potentiometer_interface()
#--------------------------------------------------------------------------------
# STUDENT CODE BEGINS
#---------------------------------------------------------------------------------

#BY: Vedant Patel (40445732)
def pick_up():

    #accounts for time delays so that the code runs properly
    time.sleep(1)

    #arm is moved to pre-determined pick-up location
    arm.move_arm(0.617, 0.054, 0.044)
    
    time.sleep(1)

    #gripper closes to its max capacity to securely hold the container
    arm.control_gripper(45)
    
    time.sleep(1)

    #gripper moves shoulder and elbow to home position but coordinates are adjusted so that gripper does not re-open and drop the container
    arm.move_arm(0.406, 0.0, 0.483)
    

#BY: Yuchen Tao (400431638)
def rotate_base(container_num):
    
    time.sleep(2)

    #loop condition variable
    correct_position = False

    #loop runs while correct position set to false. then uses conditions and if correct_position becomes true, exits the loop because the autoclave location is correct
    while correct_position == False:

        #reading an initial value for the right potentiometer    
        right_pot_val = potentiometer.right()

        #giving some time for user to use potentiometer
        time.sleep(1)

        #reading new potentiometer value
        right_pot_val2 = potentiometer.right()

        #taking difference to assist with degrees cals
        change_pot_vals = right_pot_val2 - right_pot_val

        #calculating degrees of rotation
        rotation_deg = 345 * change_pot_vals

        #rotating base acordingly
        arm.rotate_base(rotation_deg)
                  
        #check for red correct position
        if container_num == 1 or container_num ==4:
            if arm.check_autoclave("red") == True:
                #exits loop
                correct_position = True

        #check for green correct position
                
        elif container_num == 2 or container_num == 5:
            if arm.check_autoclave("green") == True:
                correct_position = True

        #check for blue correct position
        else:
            if arm.check_autoclave("blue") == True:
                correct_position = True
                
                    
#BY: Vedant Patel (40445732)
def drop_off(container_num):

    #bool varriable for while loop to run again
    run_again = True

    #initialize color as string
    color = " "

    #loop for function to read correct potentiometer value. run_again will become false and exit loop once container has been dropped off 
    while run_again == True:

        # for small object
        if potentiometer.left() > 0.5 and potentiometer.left() < 1:

            #all small objects are numbered 1-3
            if container_num <=3:

                #small red object
                if container_num == 1:
                    arm.move_arm(0.0, 0.406,0.483)
                    
                #small green object
                elif container_num == 2:
                    arm.move_arm(-0.376, 0.152,0.483)

                #small blue object
                else:
                    arm.move_arm(0.0,-0.406,0.483)

                #q arm dropoff motion for small object
                arm.rotate_elbow(-45)
                arm.rotate_shoulder(37)
                time.sleep(1)
                arm.control_gripper(-45)
                time.sleep(1)
                arm.home()

                #exits the loop once above conditions met
                run_again = False

        #for big objects   
        elif potentiometer.left() == 1:

            #big containers range from numbers 4-7
            if container_num > 3 and container_num < 7:

                #activates all autoclaves
                arm.activate_autoclaves()

                #big red object
                if container_num == 4:
                    arm.move_arm(0.0, 0.406,0.483)
                    arm.open_autoclave("red")
                    color = "red"

                #big green object
                elif container_num == 5:
                    arm.move_arm(-0.376, 0.152,0.483)
                    arm.open_autoclave("green")
                    color = "green"

                #big blue object  
                else:
                    arm.move_arm(0.0,-0.406,0.483)
                    arm.open_autoclave("blue")
                    color = "blue"

                #qarm motion for big object dropoff
                arm.rotate_shoulder(17.30)
                arm.rotate_elbow(16.30)
                time.sleep(1)
                arm.control_gripper(-45)
                time.sleep(1)
                arm.home()

                #exits loop
                run_again = False

    #closing the drawer
    arm.open_autoclave(color, False)

    #deactivating autoclaves
    arm.deactivate_autoclaves()

    #returning home position
    arm.home()

#BY: Vedant Patel (40445732)
def repeat_or_exit():

    #generating a random number 
    container_nums_list = [1,2,3,4,5,6]
    random.shuffle(container_nums_list)

    #initialize an arbitrary container number
    container_num = 0

    #looping through 6 times then exiting
    for i in container_nums_list:

        #initializing as the index i 
        container_num=i

        #while loop condition setter
        potentiometer_bool = False

        #this loop continously reads potentiometer values till both left and right are equal to 50%
        while potentiometer_bool == False:

            #if both are 50%, then only spawn cage, otherwise, keeps reading values
            if potentiometer.right() == 0.5 and potentiometer.left()==0.5:
                arm.spawn_cage(container_num)

                #exiting the loop
                potentiometer_bool = True
                
        time.sleep(0.5)

        #calling all functions 
        pick_up()
        rotate_base(container_num)
        drop_off(container_num)
        arm.home()
        
#making the final function call
repeat_or_exit()

'''
PLS READ
Quanser has a weird problem where somtimes the objcts fit right into the container and sometime they dont.
we tested the degrees of movement multiple times and we get a variance where sometimes it goes in and sometimes it dosent
'''


#---------------------------------------------------------------------------------
# STUDENT CODE ENDS
#---------------------------------------------------------------------------------
